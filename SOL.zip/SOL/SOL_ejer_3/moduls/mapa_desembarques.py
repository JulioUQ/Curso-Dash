import sys
import os 
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from dash import Dash, dcc, html
import dash_bootstrap_components as dbc
import pandas as pd
import folium
from shapely import wkt
from folium.plugins import Fullscreen

import functions as f # type: ignore



def mapa_desembarques():
    sqlstr = f"""
		Select prt.Descripcion, prt.Coordenadas.STAsText() as Coordenadas from
        (select bi.IdPuertoBase IdPuerto from [censo].[BuqueEstado] be inner join [censo].[BuqueIdentificacion] bi on be.IdBuque=bi.idbuque 
		inner join fenix.Puerto prt on bi.IdPuertoBase=prt.id
        inner join cat.Provincia pr on pr.id=prt.IdProvincia
        where  GETDATE() between be.FcEfectoInicial and be.FcEfectoFinal and
            GETDATE() between bi.FcEfectoInicial and bi.FcEfectoFinal and 
            idtipoestado in (1,5) 
        group  by bi.IdPuertoBase) A
		inner join fenix.Puerto prt on A.IdPuerto=prt.id
        """
    
    data = f.consulta(sqlstr)
    data = data.rename(columns= {"Descripcion": "PuertoDesembarque"})
    data = data.dropna()


    data_buques = f.consulta("SELECT * FROM SGP_CUADROSMANDO.cm.ccaa_desembarques")
    data_buques = data_buques[data_buques["Año"] == 2024]
    data_buques = data_buques.groupby("PuertoDesembarque")["Peso"].sum().reset_index()

    data_total = pd.merge(data, data_buques, how = "left", on = "PuertoDesembarque")

    # Calcular centro
    data["geometry"] = data["Coordenadas"].apply(wkt.loads)
    data["lat"] = data["geometry"].apply(lambda x: x.y)
    data["lon"] = data["geometry"].apply(lambda x: x.x)
    center_lat = data["lat"].mean()
    center_lon = data["lon"].mean()

    mapa = folium.Map(location=[center_lat, center_lon], zoom_start=4, height= 450)

# Añadir marcadores al mapa
    for _, row in data_total.iterrows():
        # Convertir la coordenada WKT a un objeto de Shapely
        coordenada = wkt.loads(row["Coordenadas"])
        
        # Obtener latitud y longitud
        lat, lon = coordenada.y, coordenada.x
        
        # Añadir el marcador en el mapa
        folium.CircleMarker(
            location=[lat, lon],
            radius=5 + row["Peso"] / 1000 * 0.001,  
            color="#2e86de",
            fill=True,
            fill_color="#3498db",
            fill_opacity=0.6,
            popup=f'{row["PuertoDesembarque"]}<br>Peso desembarque: {row["Peso"] / 1000} T'
        ).add_to(mapa)

    # Mostrar el mapa
    Fullscreen(position="topright").add_to(mapa)
    map_html_content = mapa.get_root().render()
   
    return dbc.Card(
        dbc.CardBody(
            html.Iframe(
                srcDoc=map_html_content,
                width="100%",  
                height=450,  
                style={"border": "none", "height": "100%"}  
            ),
            style={"height": "450px", "padding": "0px", "width": "100%", "display": "flex", "justify-content": "center", "align-items": "center"}  
        ),
        style={"padding": "0px", "border": "none", "height": "100%", "display": "flex", "justify-content": "center", "align-items": "center"}  
    )