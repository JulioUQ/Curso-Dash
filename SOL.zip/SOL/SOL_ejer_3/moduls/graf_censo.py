import sys
import os 
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from dash import Dash, dcc
import dash_bootstrap_components as dbc
import pandas as pd
import plotly.express as px

import functions as f # type: ignore


def graf_censo():
    data= f.consulta("SELECT * FROM SGP_CUADROSMANDO.cm.ccaa_desembarques WHERE año = 2024")
    data = data.groupby("Censo")["Peso"].sum().reset_index()

    data = data.sort_values(by= "Peso", ascending = False).nlargest(6, "Peso")
    data["Censo"] = data["Censo"].str.capitalize()

    bar = px.bar(data, x= "Censo", y= "Peso")
    bar.update_layout(
        xaxis_title = "",
        xaxis_tickangle = 30,
        height = 500,
        margin = dict(l=10, r=20, t= 0, b=0)
    )
    
    fig_bar = dcc.Graph(id= "graf-censo", figure= bar)

    return fig_bar