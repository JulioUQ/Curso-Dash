from dash import Dash, html, dcc
import dash_bootstrap_components as dbc
import pandas as pd

from moduls import tabla_desembarques as tb #type: ignore
from moduls import graf_censo as gc #type: ignore
from moduls import mapa_desembarques as md #type: ignore
#-------------------------------------------#

# Instanciar la app
app = Dash(__name__, external_stylesheets= [dbc.themes.BOOTSTRAP], meta_tags = [{"name": "viewport", "content": "width, initial-scale=1"}])

# Contenido
titulo = html.H1("Primer Dashboard con Dash", style={"textAlign": "center",
                                                     "color": "#A8D0EB",
                                                     "font-size": 40})
resumen = html.P("Estamos aprendiendo a usar Dash para crear dashboards interactivos.")

contenido = html.Div([
    dbc.Row([
        dbc.Col(dbc.Card([
            dbc.CardHeader(html.H4("Capturas por Censo", style= {"text-align": "center"}), style= {"backgroundColor": "#f9feff"}),
            dbc.CardBody(gc.graf_censo())
            ]), width= 4),

        dbc.Col(dbc.Card([
            dbc.CardHeader(html.H4("Desembarques por CCAA", style= {"text-align": "center"}), style= {"backgroundColor": "#f9feff"}),
            dbc.CardBody(tb.tabla_desembarques())
            ]), width= 4),

        dbc.Col(dbc.Card([
            dbc.CardHeader(html.H4("Desembarques por Puerto", style= {"text-align": "center"}), style= {"backgroundColor": "#f9feff"}),
            dbc.CardBody(md.mapa_desembarques())
            ]), width= 4),
    ])
], style= {"padding": "20px"})

# Layout (estructura)
app.layout = dcc.Loading(type= "circle", fullscreen= True, children= [titulo, resumen, contenido])

# CALLBACKS (interactividad)
#--------------
#--------------
#--------------

# Ejecución de la app
#-------------------------------------------#
if __name__ == "__main__":
    app.run_server(debug= True)