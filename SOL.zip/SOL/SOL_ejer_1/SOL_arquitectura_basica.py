from dash import Dash, html, dcc
import dash_bootstrap_components as dbc
import pandas as pd
#-------------------------------------------#

# Instanciar la app
app = Dash(__name__)

# Contenedor principal
contenido = html.Div("Hola Dash!")

# Layout (estructura)
app.layout = contenido

# CALLBACKS (interactividad)
#--------------
#--------------
#--------------

# Ejecución de la app
#-------------------------------------------#
if __name__ == "__main__":
    app.run_server(debug= True)