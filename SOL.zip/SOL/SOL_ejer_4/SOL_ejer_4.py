from dash import Dash, html, dcc
import dash_bootstrap_components as dbc
import pandas as pd

from moduls import tabla_desembarques as tb #type: ignore
from moduls import graf_especies as ge #type: ignore
from moduls import graf_provincias as gp #type: ignore
from moduls import graf_buques as gb #type: ignore
#-------------------------------------------#

# Instanciar la app
app = Dash(__name__, external_stylesheets= [dbc.themes.BOOTSTRAP], meta_tags = [{"name": "viewport", "content": "width, initial-scale=1"}])

# Contenido
titulo = html.H1("Ventas y Desembarques", style={"textAlign": "center",
                                                     "color": "#000000",
                                                     "font-size": 40})


contenido = html.Div([
    dbc.Row([
        dbc.Col(dbc.Card([
            dbc.CardHeader(html.H4("Principales Especies", style= {"text-align": "center"}), style= {"backgroundColor": "#f9feff"}),
            dbc.CardBody(ge.graf_especies())
            ]), width= 3),

        dbc.Col(dbc.Card([
            dbc.CardHeader(html.H4("Principales puertos de Desembarque", style= {"text-align": "center"}), style= {"backgroundColor": "#f9feff"}),
            dbc.CardBody(tb.tabla_desembarques())
            ]), width= 4),

        dbc.Col(dbc.Card([
            dbc.CardHeader(html.H4("Principales Provincias de Desembarque", style= {"text-align": "center"}), style= {"backgroundColor": "#f9feff"}),
            dbc.CardBody(gp.provincias_desembarque())
            ]), width= 5),
    ]),
    dbc.Row([
        dbc.Card([dbc.CardHeader(html.H4("Variación del Número de Buques", style= {"text-align": "center"}), style= {"backgroundColor": "#f9feff"}),
                  dbc.CardBody(gb.variacion_buques())
                   ])
    ])
], style= {"padding": "20px"})

# Layout (estructura)
app.layout = dcc.Loading(type= "circle", fullscreen= True, children= [titulo, contenido])

# CALLBACKS (interactividad)
#--------------
#--------------
#--------------

# Ejecución de la app
#-------------------------------------------#
if __name__ == "__main__":
    app.run_server(debug= True)